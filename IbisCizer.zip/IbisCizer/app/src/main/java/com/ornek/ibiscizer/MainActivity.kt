package com.ornek.ibiscizer

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val IBIS = "jp.ne.ibis.ibispaintx.app"
    private lateinit var prefs: android.content.SharedPreferences
    private var bmp: Bitmap? = null
    private lateinit var preview: ImageView

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            contentResolver.openInputStream(uri)?.use { bmp = BitmapFactory.decodeStream(it) }
            preview.setImageBitmap(bmp)
            Toast.makeText(this, "Resim seçildi. 'Çizdir' e bas.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("ayar", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        val sc = ScrollView(this).apply { addView(root) }
        setContentView(sc)

        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; root.addView(this) }
        fun lbl(t: String) = TextView(this).apply { text = t; setPadding(0, 24, 0, 0); root.addView(this) }
        fun seek(label: String, key: String, min: Int, max: Int, def: Int) {
            val tv = lbl("$label: ${prefs.getInt(key, def)}")
            root.addView(SeekBar(this).apply {
                this.max = max - min; progress = prefs.getInt(key, def) - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { prefs.edit().putInt(key, p + min).apply(); tv.text = "$label: ${p + min}" }
                    override fun onStartTrackingTouch(sb: SeekBar?) {}
                    override fun onStopTrackingTouch(sb: SeekBar?) {}
                })
            })
        }

        btn("1) Erişilebilirlik servisini aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2) Resim seç") { picker.launch("image/*") }
        preview = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 500); adjustViewBounds = true }
        root.addView(preview)

        val sw = Switch(this).apply { text = "Renkli çiz (kapalı = renksiz/çizgi)"; isChecked = prefs.getBoolean("renkli", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("renkli", c).apply() } }
        root.addView(sw)
        seek("Detay (ızgara genişliği)", "detay", 40, 220, 120)
        seek("Kenar hassasiyeti (renksiz)", "esik", 50, 600, 250)
        seek("Renk sayısı (renkli)", "renk", 2, 12, 6)
        seek("Renk seçme bekleme sn (renkli)", "bekle", 3, 30, 10)
        seek("Çizgi arası bekleme ms", "gap", 0, 200, 20)
        lbl("Tuval alanı (% ekran) — ibis'te tuvalin ekranda kapladığı yere göre ayarla")
        seek("Sol %", "sol", 0, 50, 0); seek("Üst %", "ust", 0, 50, 12)
        seek("Sağ %", "sag", 50, 100, 100); seek("Alt %", "alt", 50, 100, 85)

        btn("3) ÇİZDİR") { start() }
        btn("Durdur") { DrawService.stop = true }

        if (intent?.action == "com.ornek.ibiscizer.SEC") picker.launch("image/*")  // kısayoldan gelince direkt galeri
    }

    private fun start() {
        val b = bmp ?: return toast("Önce resim seç")
        val svc = DrawService.instance ?: return toast("Erişilebilirlik servisini aç (İbis Çizer)")
        val plan = if (prefs.getBoolean("renkli", false))
            ImageToStrokes.colored(b, prefs.getInt("detay", 120), prefs.getInt("renk", 6))
        else ImageToStrokes.mono(b, prefs.getInt("detay", 120), prefs.getInt("esik", 250))
        val dm = resources.displayMetrics
        val area = floatArrayOf(
            dm.widthPixels * prefs.getInt("sol", 0) / 100f, dm.heightPixels * prefs.getInt("ust", 12) / 100f,
            dm.widthPixels * prefs.getInt("sag", 100) / 100f, dm.heightPixels * prefs.getInt("alt", 85) / 100f)
        val i = packageManager.getLaunchIntentForPackage(IBIS) ?: return toast("ibis Paint yüklü değil")
        startActivity(i)
        toast("ibis açılıyor… yeni boş bir tuval aç, çizim 8 sn sonra başlar")
        Handler(Looper.getMainLooper()).postDelayed({
            svc.draw(plan, area, prefs.getInt("bekle", 10) * 1000L, prefs.getInt("gap", 20).toLong())
        }, 8000)
    }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()
}
