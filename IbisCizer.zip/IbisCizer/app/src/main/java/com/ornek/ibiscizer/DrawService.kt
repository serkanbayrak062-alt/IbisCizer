package com.ornek.ibiscizer

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class DrawService : AccessibilityService() {
    companion object {
        var instance: DrawService? = null
        @Volatile var stop = false
    }
    private val h = Handler(Looper.getMainLooper())

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop = true }
    override fun onDestroy() { instance = null; super.onDestroy() }

    /**
     * @param area tuvalin ekrandaki alanı (px): [sol, üst, sağ, alt]
     * @param colorWaitMs renkli modda her renk için, rengi ibis'te seçmen için beklenecek süre
     * @param gap  iki çizgi arası bekleme (ms)
     */
    fun draw(plan: Plan, area: FloatArray, colorWaitMs: Long, gap: Long) {
        stop = false
        val aw = area[2] - area[0]; val ah = area[3] - area[1]
        val s = minOf(aw / plan.w, ah / plan.h)
        val ox = area[0] + (aw - plan.w * s) / 2f
        val oy = area[1] + (ah - plan.h * s) / 2f
        val queue = ArrayDeque<Any>()  // Seg veya Int(renk) veya Long(bekleme)
        for (g in plan.groups) {
            if (g.color != null) queue.add(g.color)
            g.segs.forEach { queue.add(it) }
        }
        fun step() {
            if (stop) { toast("Çizim durduruldu"); return }
            val it = queue.removeFirstOrNull() ?: run { toast("Çizim bitti ✔"); return }
            when (it) {
                is Int -> {
                    toast("Şimdi ibis'te şu rengi seç: #%06X  (${colorWaitMs / 1000} sn)".format(it and 0xFFFFFF))
                    h.postDelayed({ step() }, colorWaitMs)
                }
                is Seg -> {
                    val p = Path()
                    val x1 = ox + (it.x1 + 0.5f) * s; val y1 = oy + (it.y1 + 0.5f) * s
                    val x2 = ox + (it.x2 + 0.5f) * s; val y2 = oy + (it.y2 + 0.5f) * s
                    p.moveTo(x1, y1); p.lineTo(if (x2 == x1 && y2 == y1) x2 + 1f else x2, y2)
                    // Tek stroke / tek gesture: birden çok stroke aynı anda çok parmak sayılır (zoom yapar!)
                    val gd = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 15)).build()
                    val ok = dispatchGesture(gd, object : GestureResultCallback() {
                        override fun onCompleted(g: GestureDescription?) { h.postDelayed({ step() }, gap) }
                        override fun onCancelled(g: GestureDescription?) { h.postDelayed({ step() }, gap) }
                    }, null)
                    if (!ok) h.postDelayed({ step() }, 50)
                }
            }
        }
        step()
    }

    private fun toast(m: String) = h.post { Toast.makeText(this, m, Toast.LENGTH_LONG).show() }
}
