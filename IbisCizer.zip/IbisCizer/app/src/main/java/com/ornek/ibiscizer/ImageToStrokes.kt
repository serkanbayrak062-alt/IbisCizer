package com.ornek.ibiscizer

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.abs
import kotlin.math.max
import kotlin.random.Random

/** Görüntüdeki bir çizgi parçası (ızgara koordinatında). */
data class Seg(val x1: Int, val y1: Int, val x2: Int, val y2: Int)
/** Aynı renkte çizilecek parçalar. color == null -> mevcut renk (siyah/ibis'te seçili) */
data class Group(val color: Int?, val segs: List<Seg>)
data class Plan(val w: Int, val h: Int, val groups: List<Group>)

object ImageToStrokes {

    fun scale(src: Bitmap, width: Int): Bitmap {
        val h = max(1, src.height * width / src.width)
        return Bitmap.createScaledBitmap(src, width, h, true)
    }

    /** Renksiz: kenar (Sobel) çizgi çizimi. */
    fun mono(src: Bitmap, width: Int, threshold: Int): Plan {
        val b = scale(src, width); val w = b.width; val h = b.height
        val g = IntArray(w * h) { val c = b.getPixel(it % w, it / w); (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10 }
        val edge = Array(h) { BooleanArray(w) }
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            fun p(dx: Int, dy: Int) = g[(y + dy) * w + x + dx]
            val gx = -p(-1,-1) - 2*p(-1,0) - p(-1,1) + p(1,-1) + 2*p(1,0) + p(1,1)
            val gy = -p(-1,-1) - 2*p(0,-1) - p(1,-1) + p(-1,1) + 2*p(0,1) + p(1,1)
            edge[y][x] = abs(gx) + abs(gy) > threshold
        }
        val segs = ArrayList<Seg>()
        val used = Array(h) { BooleanArray(w) }
        // yatay koşular
        for (y in 0 until h) { var x = 0
            while (x < w) { if (edge[y][x]) { var e = x; while (e + 1 < w && edge[y][e + 1]) e++
                if (e > x) { segs += Seg(x, y, e, y); for (i in x..e) used[y][i] = true }
                x = e + 1 } else x++ } }
        // dikey koşular (yatayda kapsanmayan pikseller)
        for (x in 0 until w) { var y = 0
            while (y < h) { if (edge[y][x] && !used[y][x]) { var e = y; while (e + 1 < h && edge[e + 1][x] && !used[e + 1][x]) e++
                segs += Seg(x, y, x, e); y = e + 1 } else y++ } }
        return Plan(w, h, listOf(Group(null, segs)))
    }

    /** Renkli: k renge indirge, her rengi yatay koşularla doldur. */
    fun colored(src: Bitmap, width: Int, k: Int): Plan {
        val b = scale(src, width); val w = b.width; val h = b.height
        val px = IntArray(w * h) { b.getPixel(it % w, it / w) }
        // basit k-means
        val rnd = Random(1)
        var cent = Array(k) { px[rnd.nextInt(px.size)] }
        val lab = IntArray(px.size)
        fun d(a: Int, c: Int): Int { val dr = Color.red(a)-Color.red(c); val dg = Color.green(a)-Color.green(c); val db = Color.blue(a)-Color.blue(c); return dr*dr+dg*dg+db*db }
        repeat(6) {
            for (i in px.indices) { var best = 0; var bd = Int.MAX_VALUE
                for (j in cent.indices) { val dd = d(px[i], cent[j]); if (dd < bd) { bd = dd; best = j } }
                lab[i] = best }
            val sr = LongArray(k); val sg = LongArray(k); val sb = LongArray(k); val n = IntArray(k)
            for (i in px.indices) { val l = lab[i]; sr[l]+=Color.red(px[i]); sg[l]+=Color.green(px[i]); sb[l]+=Color.blue(px[i]); n[l]++ }
            cent = Array(k) { if (n[it]==0) cent[it] else Color.rgb((sr[it]/n[it]).toInt(), (sg[it]/n[it]).toInt(), (sb[it]/n[it]).toInt()) }
        }
        // açıktan koyuya: önce açık renkler, detay için koyular sonra
        val order = cent.indices.sortedByDescending { Color.red(cent[it]) + Color.green(cent[it]) + Color.blue(cent[it]) }
        val groups = ArrayList<Group>()
        for (c in order) {
            val segs = ArrayList<Seg>()
            for (y in 0 until h) { var x = 0
                while (x < w) { if (lab[y*w+x] == c) { var e = x; while (e+1 < w && lab[y*w+e+1] == c) e++
                    segs += Seg(x, y, e, y); x = e + 1 } else x++ } }
            if (segs.isNotEmpty()) groups += Group(cent[c], segs)
        }
        return Plan(w, h, groups)
    }
}
