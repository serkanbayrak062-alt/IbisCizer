# İbis Çizer

Android Studio ile aç -> Build > Build APK. Telefona kur.
1. Uygulamayı aç -> "Erişilebilirlik servisini aç" -> İbis Çizer'i etkinleştir.
2. Ana ekranda uygulama simgesine uzun bas -> "Resim seç ve çiz" kısayolunu ana ekrana sürükle.
3. Kısayol galeriyi açar, resmi seç, uygulamada ÇİZDİR'e bas. ibis açılır, boş tuvalde çizim başlar.
Ayarlar: renkli/renksiz, detay, hassasiyet, hız, tuval alanı.
ibis'te önce fırça boyutunu küçük (1-3 px) bir kalem yap, tuvali tam ekran/zoom'suz bırak.
